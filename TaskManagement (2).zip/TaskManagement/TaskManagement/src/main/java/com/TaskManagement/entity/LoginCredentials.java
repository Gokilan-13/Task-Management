package com.TaskManagement.entity;

import lombok.Data;

@Data
public class LoginCredentials {
    private String emailId;
    private String password;
}
